<?php

$slug = isset($_GET['slug']) ? $_GET['slug'] : 'menus';

if($slug == 'menus'){
	require_once( 'core/menus.php' );
} elseif($slug == 'widgets'){
	require_once( 'core/widgets.php' );
}

?>