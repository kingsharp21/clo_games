var CA_API_VERSION = '1.0.0';
class CA_API {
	constructor(){
		this.current_user = null;
	}
	submit_score(val){
		if(val){
			val = Number(val);
			val = btoa((val/1.33));
			let wait = new Promise((res) => {
				this.send('submit', val).then((result)=>{
					if(result){
						res(result);
					} else {
						res(false);
					}
				});
			});
			return wait;
		}
	}
	send(action, val = 0, conf = null){
		let game_id = this.game_id;
		let cur_url = window.location.href;
		let ref;
		if(cur_url[cur_url.length-1] === '/'){
			ref = cur_url.substring(
			    cur_url.indexOf("/games/") + 7, 
			    cur_url.length-1
			);
		} else if(cur_url.substr(cur_url.length-5, cur_url.length) === '.html') {
			ref = cur_url.substring(
			    cur_url.indexOf("/games/") + 7, 
			    cur_url.lastIndexOf("/index.html")
			);
		}
		let wait = new Promise((res) => {
			let params = 'action='+action+'&value='+val+'&ref='+ref;
			if(conf){
				params += '&conf='+conf;
			}
			let xhr = new XMLHttpRequest();
			xhr.open('POST', '/includes/api.php', true);
			xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhr.onload = function() {
				if (xhr.status === 200) {
					if(xhr.responseText != 'ok'){
						try {
							JSON.parse(xhr.responseText);
						} catch {
							console.warn('CA Error/Fail');
							console.log(xhr.responseText);
						}
					}
					res(xhr.responseText);
				}
				else {
					res(false);
				}
			}.bind(this);
			xhr.send(params);
		});
		return wait;
	}
	get_current_user(){
		let wait = new Promise((res) => {
			this.send('get_current_user').then((result)=>{
				if(result){
					this.current_user = JSON.parse(result);
					res(result);
				} else {
					res(false);
				}
			});
		});
		return wait;
	}
	get_scoreboard(conf){
		let wait = new Promise((res) => {
			this.send('get_scoreboard', 0, JSON.stringify(conf)).then((val)=>{
				if(val){
					res(val);
				} else {
					res(false);
				}
			});
		});
		return wait;
	}
}
console.log('CA API v'+CA_API_VERSION+' loaded!')