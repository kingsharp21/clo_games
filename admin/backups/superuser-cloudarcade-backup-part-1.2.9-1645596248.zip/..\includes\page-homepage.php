<?php

require_once( TEMPLATE_PATH . '/functions.php' );

$page_title = SITE_TITLE . ' | '.SITE_DESCRIPTION;
$meta_description = META_DESCRIPTION;

require( TEMPLATE_PATH . '/home.php' );

?>