<?php

require_once( ABSPATH . CLASS_PATH . "/Page.php" );
require_once( ABSPATH . CLASS_PATH . "/Category.php" );
require_once( ABSPATH . CLASS_PATH . "/Game.php" );
require_once( ABSPATH . CLASS_PATH . "/User.php" );
require_once( ABSPATH . CLASS_PATH . "/Auth.php" );
require_once( ABSPATH . CLASS_PATH . "/Widget.php" );

?>