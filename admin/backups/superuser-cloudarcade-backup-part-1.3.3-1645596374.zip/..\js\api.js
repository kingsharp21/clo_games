var CA_API_VERSION = '1.1.0';
class CA_API {
	constructor(conf = {}){
		this.current_user = null;
		this.debug = false;
		if(conf.debug){
			this.debug = true;
		}
	}
	submit_score(val){
		if(val){
			val = Number(val);
			val = btoa((val/1.33));
			let wait = new Promise((res) => {
				this.send('submit', val).then((result)=>{
					if(result){
						this.log('SUBMIT SCORE');
						res(result);
					} else {
						this.log('FAILED SUBMIT SCORE');
						res(false);
					}
				});
			});
			return wait;
		}
	}
	send(action, val = 0, conf = null){
		let game_id = this.game_id;
		let cur_url = window.location.href;
		let ref;
		if(cur_url[cur_url.length-1] === '/'){
			ref = cur_url.substring(
			    cur_url.indexOf("/games/") + 7, 
			    cur_url.length-1
			);
		} else if(cur_url.substr(cur_url.length-5, cur_url.length) === '.html') {
			ref = cur_url.substring(
			    cur_url.indexOf("/games/") + 7, 
			    cur_url.lastIndexOf("/index.html")
			);
		}
		let wait = new Promise((res) => {
			let params = 'action='+action+'&value='+val+'&ref='+ref;
			if(conf){
				params += '&conf='+conf;
			}
			let xhr = new XMLHttpRequest();
			xhr.open('POST', '/includes/api.php', true);
			xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhr.onload = function() {
				if (xhr.status === 200) {
					if(xhr.responseText != 'ok'){
						try {
							JSON.parse(xhr.responseText);
						} catch {
							console.warn('CA Error/Fail');
							console.log(xhr.responseText);
						}
					}
					res(xhr.responseText);
				}
				else {
					res(false);
				}
			}.bind(this);
			xhr.onerror = function() {
				res(false);
			}
			xhr.send(params);
		});
		return wait;
	}
	get_current_user(){
		let wait = new Promise((res) => {
			this.send('get_current_user').then((result)=>{
				if(result){
					this.current_user = JSON.parse(result);
					res(result);
				} else {
					res(false);
				}
			});
		});
		return wait;
	}
	get_scoreboard(conf){
		let wait = new Promise((res) => {
			this.send('get_scoreboard', 0, JSON.stringify(conf)).then((val)=>{
				if(val){
					res(val);
				} else {
					this.log('FAILED GET LEADERBOARD');
					res(false);
				}
			});
		});
		return wait;
	}
	log(msg = ''){
		if(this.debug){
			console.log('CA: '+msg);
		}
	}
	prepare_ad_element(){
		let div = document.getElementById('CA_AD');
		if(!div){
			let link = document.createElement('link');
		    link.rel = 'stylesheet';
		    link.href = '/admin/style/api.css';
		    document.head.appendChild(link);
			let elem = document.createElement('div');
			elem.id = 'CA_AD';
			document.body.appendChild(elem);
		}
		let html = '<div class="popbox">';
		html += '<div class="popup-overlay">';
		html += '<div class="pop-content" id="ad-content">';
		html += '<div class="ad-loader"></div>';
		html += '</div>';
		html += '</div>';
		html += '</div>';
		document.getElementById("CA_AD").innerHTML = html;
	}
	show_ad_element(val){
		let div = document.getElementById('ad-content');
		let html = '<a href="'+val.url+'" target="_blank">';
		html += '<img class="banner-content" src="'+val.src+'">';
		html += '</a>';
		html += '<div id="ca_b_close">';
		if(!val.delay){
			html += '<button class="popbox-close-button" onclick="ca_api.close_ad()"></button>';
		}
		html += '</div>';
		html += '<div id="ad-delay"></div>';
		div.innerHTML = html;
		if(val.delay){
			document.getElementById('ad-delay').innerHTML = 'Wait '+(val.delay)+' seconds';
			let count = 0;
			let interval = setInterval(()=>{
				count++;
				document.getElementById('ad-delay').innerHTML = 'Wait '+(val.delay-count)+' seconds';
				if(count >= val.delay){
					document.getElementById('ad-delay').innerHTML = '';
					document.getElementById('ca_b_close').innerHTML = '<button class="popbox-close-button" onclick="ca_api.close_ad()"></button>';
					clearInterval(interval);
				}
			}, 1000);
		}
	}
	show_ad(tag = null){
		this.log('TRIGGER SHOW AD');
		this.paused();
		this.ad_trigger();
		this.prepare_ad_element();
		let wait = new Promise((res) => {
			this.send('load_ad', tag).then((val)=>{
				this.ad_start();
				if(val){
					try {
						this.log('AD LOADED');
						val = JSON.parse(val);
						this.show_ad_element(val);
						res(val);
					} catch {
						this.log('AD FAILED TO PARSE');
						this.ad_error();
						this.remove_ad();
						res(false);
					}
				} else {
					this.log('AD FAILED TO LOAD');
					this.ad_error();
					this.remove_ad();
					res(false);
				}
			});
				
		});
		return wait;
	}
	close_ad(){
		this.log('AD CLOSED BY PLAYER');
		this.remove_ad();
		this.ad_closed();
	}
	remove_ad(){
		if(document.getElementById('CA_AD')){
			document.getElementById('CA_AD').innerHTML = '';
		}
		this.ad_end();
		this.resume();
	}
	// Callbacks
	paused(){
		//
	}
	resume(){
		//
	}
	ad_trigger(){
		//
	}
	ad_start(){
		//
	}
	ad_end(){
		//
	}
	ad_closed(){
		// Ad closed by Player
	}
	ad_error(e){
		//
	}
	
}
console.log('CA API v'+CA_API_VERSION+' loaded!');

var ca_api = new CA_API;