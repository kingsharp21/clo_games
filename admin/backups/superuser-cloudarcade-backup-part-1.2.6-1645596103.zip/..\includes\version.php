<?php

define( "VERSION", "1.2.6" );

?>