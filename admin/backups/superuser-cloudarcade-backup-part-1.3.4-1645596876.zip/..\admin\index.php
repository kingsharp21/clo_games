<?php

require('../config.php');
require('../init.php');

header( "Location: ".DOMAIN.'admin.php' );

?>