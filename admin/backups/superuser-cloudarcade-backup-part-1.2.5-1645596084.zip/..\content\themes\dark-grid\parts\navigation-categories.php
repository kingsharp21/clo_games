<nav class='greedy'>
	<?php list_categories() ?>
	<button><?php _e('MORE') ?></button>
  	<ul class='hidden-links hidden'></ul>
</nav>