<?php
define( "DB_DSN", "mysql:host=localhost;dbname=cloogame" );
define( "DB_USERNAME", "root" );
define( "DB_PASSWORD", "" );
?>